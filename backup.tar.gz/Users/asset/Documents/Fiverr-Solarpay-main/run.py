from fastapi import FastAPI, Request
import logging
import os
from google.cloud import storage
from gtts import gTTS
import config  # Убедитесь, что config импортирован

app = FastAPI()

logging.basicConfig(level=logging.INFO)

def save_file(file_path, content):
    try:
        directory = os.path.dirname(file_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        with open(file_path, 'wb') as file:
            file.write(content)
        logging.info(f"Файл успешно сохранен по пути {file_path}")
    except Exception as e:
        logging.error(f"Ошибка при сохранении файла по пути {file_path}: {e}")

def upload_file_to_gcs(source_file_path, destination_blob_name):
    """Uploads a file to the bucket."""
    bucket_name = 'assetlogistics'
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(destination_blob_name)

        blob.upload_from_filename(source_file_path)

        # Настройка доступа должна быть выполнена на уровне корзины, а не объекта
        logging.info(f"File {source_file_path} uploaded to {destination_blob_name}.")
        return f"https://storage.googleapis.com/{bucket_name}/{destination_blob_name}"
    except Exception as e:
        logging.error(f"Error uploading file to GCS: {e}")
        return None

@app.post('/telegram')
async def telegram(request: Request):
    try:
        body = await request.json()
        logging.info(f"Получен запрос: {body}")
        
        sender_id = body['message']['from']['id']
        if 'voice' in body['message'].keys():
            file_id = body['message']['voice']['file_id']
            file_path = get_file_path(file_id)  # Реализуйте функцию get_file_path для получения пути к файлу
            if file_path['status'] == 1:
                local_file_path = save_file_and_get_local_path(file_path['file_path'])
                if local_file_path['status'] == 1:
                    transcript = transcript_audio(local_file_path['local_file_path'], local_file_path['file_id'])
                    if transcript['status'] == 1:
                        query = chat_completion(transcript['transcript'])
                    else:
                        query = body['message']['text']
                else:
                    query = body['message']['text']
                
                response = chat_completion(query)
                
                if config.REPLY_TYPE == 'audio':  # Использование переменной config
                    audio_file_path, audio_file_name = text_to_speech(response)
                    save_file(audio_file_path, generate_audio_content(response))  # Функция generate_audio_content возвращает аудиоконтент
                    public_url = upload_file_to_gcs(audio_file_path, audio_file_name)
                    send_audio(sender_id, public_url, 'Response')
                else:
                    send_message(sender_id, response)
        return {'status': 'ok'}
    except Exception as e:
        logging.error(f"Ошибка при обработке запроса: {e}")
        return {'status': 'error', 'message': str(e)}

def get_file_path(file_id):
    # Реализуйте эту функцию для возврата пути к файлу на основе file_id
    # Пример:
    return {'status': 1, 'file_path': '/tmp/telegrambot/sample.mp3'}

def save_file_and_get_local_path(file_path):
    # Реализуйте эту функцию для сохранения файла и возврата локального пути к файлу
    # Пример:
    return {'status': 1, 'local_file_path': file_path, 'file_id': 'sample_id'}

def transcript_audio(file_path, file_id):
    # Реализуйте эту функцию для транскрипции аудиофайла
    # Пример:
    return {'status': 1, 'transcript': 'пример транскрипта'}

def chat_completion(query):
    # Реализуйте эту функцию для получения ответа на основе запроса
    # Пример:
    return 'пример ответа'

def text_to_speech(response):
    # Реализуйте эту функцию для преобразования текста в речь
    # Пример:
    audio_file_path = '/tmp/telegrambot/sample_response.mp3'
    audio_file_name = 'sample_response.mp3'
    # Используйте pydub или другой инструмент для создания MP3 файла
    from pydub.generators import Sine
    sine_wave = Sine(1000).to_audio_segment(duration=5000)  # 5 секунд синусоидальной волны
    sine_wave.export(audio_file_path, format="mp3")
    return audio_file_path, audio_file_name

def generate_audio_content(response):
    # Функция для генерации контента аудиофайла на основе ответа
    # Используйте библиотеку, например gTTS или pydub, для создания аудиофайла
    tts = gTTS(response, lang='en')
    tts.save('/tmp/telegrambot/generated_response.mp3')
    with open('/tmp/telegrambot/generated_response.mp3', 'rb') as f:
        return f.read()

def send_audio(sender_id, public_url, response_type):
    # Реализуйте эту функцию для отправки аудио-ответа
    pass

def send_message(sender_id, response):
    # Реализуйте эту функцию для отправки текстового ответа
    pass
