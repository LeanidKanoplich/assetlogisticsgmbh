from pydub.generators import Sine

# Создание директории, если она не существует
import os
directory = '/tmp/telegrambot/'
if not os.path.exists(directory):
    os.makedirs(directory)

# Генерация синусоидального сигнала и его сохранение в MP3 файл
sine_wave = Sine(1000).to_audio_segment(duration=5000)  # 5 секунд
sine_wave.export('/tmp/telegrambot/c4249170-3148-11ef-b1d9-9351419ea0a2.mp3', format="mp3")
